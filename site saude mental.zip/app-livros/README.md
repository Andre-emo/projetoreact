guia para rodar o projeto

Pré-requisitos: Para rodar o projeto, você precisa ter o Node.js e o npm instalados no computador. Também é sugerido o uso de um editor de código, como o Visual Studio Code.

Acesse o terminal e digite o comando abaixo para clonar o repositório do projeto:

https://github.com/Andre-emo/projetoreact

Ainda no terminal, com a pasta do projeto aberta, execute o comando npm install
Após alguns segundos, o projeto estará acessível normalmente em localhost no navegador.

Principais comandos úteis
Para instalar dependências: npm install
Para rodar o projeto: npm start
Para gerar a build de produção: npm run build
Para instalar styled-components (se necessário): npm install styled-components
Para instalar react-router-dom (se necessário): npm install react-router-dom