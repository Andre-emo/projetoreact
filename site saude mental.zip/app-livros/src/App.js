import React, { useRef } from 'react'
import './app.css'
import { BrowserRouter, Routes, Route } from 'react-router-dom'
import Header from './components/Header'
import Conheca from './components/Conheca'
import Uaps from './components/Uaps'
import Caps from './components/Caps'
import Posto from './components/Posto'
import Form from './components/Form'

function App() {
  const formRef = useRef(null)
  const scrollToForm = () => {
    if (formRef.current) {
      formRef.current.scrollIntoView({ behavior: 'smooth' })
    }
  }

  return (
    <BrowserRouter>
      <Header scrollToForm={scrollToForm} />
      <Routes>
        <Route path="/" element={
          <>
            <Conheca />
            <Uaps />
            <Caps />
            <Posto />
            <Form ref={formRef} />
          </>
        } />
        <Route path="/formulario" element={<Form />} />
      </Routes>
    </BrowserRouter>
  )
}

export default App