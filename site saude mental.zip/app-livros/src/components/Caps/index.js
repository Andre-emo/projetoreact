import styled from 'styled-components'
import caps from "../../images/caps.jpg"

const Title = styled.h2`
  color: rgb(0, 0, 0);
  text-align: left; 
  width: 100%;
  text-shadow: 5px 2px 2px rgba(0, 0, 0, 0.2);
  margin-bottom: 1rem;
  text-align: left; 
`

const Subtitle = styled.h3`
  color: rgb(0, 0, 0);
  text-align: left; 
  width: 100%;
  text-shadow: 5px 2px 2px rgba(0, 0, 0, 0.2);
  margin: 1.5rem 0 0.5rem;
  text-align: left; 
`

const Text = styled.p`
  text-align: left; 
  width: 100%;
  text-shadow: 5px 2px 2px rgba(0, 0, 0, 0.2);
  margin-bottom: 1rem;
  line-height: 1.5;
  text-align: left; 
`
const TopicList = styled.ul`
  list-style-type: none;
  padding-left: 1.5rem;
  margin: 1rem 0;
  text-align: left;
`

const TopicItem = styled.li`
  position: relative;
  margin-bottom: 0.8rem;
  line-height: 1.5;
  text-align: left; 
  
  &::before {
    content: "•";
    color:rgb(14, 27, 167);
    font-weight: bold;
    position: absolute;
    left: -1rem;
  }
`

const TopicTitle = styled.strong`
  color: #333;
`

const SectionContainer = styled.section`
  padding: 1em;
  text-align: left;
`
function Caps(){
    return(
        <SectionContainer id="caps">
            <Title>Centro de Atenção Psicosocial (CAPS)</Title>
            <img src={caps} alt='imagem do caps' className='imagemCaps'
            style={{width: '800px', height: 'auto',borderRadius: '10px'}}></img>
            <Subtitle>Localização e Atendimento</Subtitle>
            <Text>A CAPS é um local especializado em situações de risco médio e grave, caso sinta 
                que sua situação está assim, pode buscar auxílio lá.</Text>
            <Text>O local conta com atendimento psicológico e psiquiátrico,
                além de ter também grupos de apoio, como o alcóolatras anônimos.</Text>
            <TopicList>
                <TopicItem>
                    <TopicTitle>Endereço: </TopicTitle> R. Ver. Antônio Pozzan, 609 - Centro
                </TopicItem>
            </TopicList>    
            <TopicList>
                <TopicItem>
                    <TopicTitle>Telefone: </TopicTitle>(44) 3649-6234
                </TopicItem>
            </TopicList>

        </SectionContainer>
    )

}


export default Caps