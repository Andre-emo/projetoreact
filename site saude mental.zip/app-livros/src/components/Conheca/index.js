import styled from 'styled-components'

const Title = styled.h2`
  color: rgb(0, 0, 0);
  text-align: left; 
  width: 100%;
  text-shadow: 5px 2px 2px rgba(0, 0, 0, 0.2);
  margin-bottom: 1rem;
  text-align: left; 
`

const Subtitle = styled.h3`
  color: rgb(0, 0, 0);
  text-align: left; 
  width: 100%;
  text-shadow: 5px 2px 2px rgba(0, 0, 0, 0.2);
  margin: 1.5rem 0 0.5rem;
  text-align: left; 
`

const Text = styled.p`
  text-align: left; 
  width: 100%;
  text-shadow: 5px 2px 2px rgba(0, 0, 0, 0.2);
  margin-bottom: 1rem;
  line-height: 1.5;
  text-align: left; 
`

const TopicList = styled.ul`
  list-style-type: none;
  padding-left: 1.5rem;
  margin: 1rem 0;
  text-align: left;
`

const TopicItem = styled.li`
  position: relative;
  margin-bottom: 0.8rem;
  line-height: 1.5;
  text-align: left; 
  
  &::before {
    content: "•";
    color:rgb(14, 27, 167);
    font-weight: bold;
    position: absolute;
    left: -1rem;
  }
`

const TopicTitle = styled.strong`
  color: #333;
`

const SectionContainer = styled.section`
  padding: 1em;
  text-align: left;
`

function Conheca() {
  return (
    <SectionContainer id="conhecamais">
      <Title>Conheça mais</Title>
      <Text>Este site foi montado para um projeto da matéria de "Desenvolvimento de Sistemas para Internet", ministrada pelo Prof. Dr. Anderson da Silva Marcolino.</Text>

      <Text>O objetivo deste projeto é propagar os canais existentes que estão aqui para auxiliar os alunos passando por dificuldades psicológicas.</Text>

      <Text>Caso necessite de atendimento, não hesite em falar com qualquer um dos locais, existem ótimos profissionais dispostos a te ouvir.</Text>

      <Title>Cuidar da mente também é estudar</Title>
      <Text>Os transtornos psicológicos – como ansiedade, depressão, síndrome do pânico e burnout – são mais comuns do que imaginamos, especialmente na vida acadêmica. Pressão por notas, prazos apertados, cobranças pessoais e a adaptação a novos ambientes podem desencadear ou agravar essas condições.</Text>
      
      <Subtitle>Você não está sozinho(a).</Subtitle>
      <Text>Muitos estudantes passam por desafios similares, mas um erro frequente é acreditar que "isso é fraqueza" ou "vai passar sozinho". Ignorar os sinais do corpo e da mente pode levar ao agravamento dos sintomas, afetando não só seu rendimento nos estudos, mas também sua qualidade de vida.</Text>
      
      <Subtitle>Por Que Buscar Ajuda é Importante?</Subtitle>
      <TopicList>
        <TopicItem>
          <TopicTitle>Saúde é prioridade:</TopicTitle> Assim como tratar uma dor física, cuidar da mente exige atenção profissional.
        </TopicItem>
        <TopicItem>
          <TopicTitle>Prevenção:</TopicTitle> Intervenções precoces evitam crises mais severas.
        </TopicItem>
        <TopicItem>
          <TopicTitle>Ferramentas para lidar:</TopicTitle> Psicólogos e psiquiatras ajudam a desenvolver estratégias práticas para gerenciar emoções e situações desafiadoras.
        </TopicItem>
        <TopicItem>
          <TopicTitle>Apoio especializado:</TopicTitle> Locais como CAPS, UAPS e serviços universitários oferecem atendimento gratuito ou acessível.
        </TopicItem>
      </TopicList>
      <Subtitle>Não subestime seu sofrimento.</Subtitle>
      <Text>Pedir ajuda é um ato de coragem e autocuidado. Se você está se sentindo sobrecarregado(a), desmotivado(a) ou percebe mudanças significativas em seu comportamento:</Text>
      <TopicList>
        <TopicItem>
          <TopicTitle>Fale com alguém de confiança (amigos, familiares, professores).</TopicTitle>
        </TopicItem>
        <TopicItem>
          <TopicTitle>Procure os serviços de saúde listados neste site.</TopicTitle>
        </TopicItem>
        <TopicTitle>
          <TopicItem>Lembre-se: Buscar ajuda não te define – te fortalece</TopicItem>
        </TopicTitle>
      </TopicList>
      <Text>Seu bem-estar mental é tão importante quanto suas conquistas acadêmicas.</Text>
    </SectionContainer>
  )
}

export default Conheca
