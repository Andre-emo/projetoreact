import styled from 'styled-components'
import Input from '../Input'
import React, { forwardRef } from 'react'


const FormContainer = styled.section`
    padding-top: 5em;
    color: rgb(0, 0, 0);
    text-align: center;
    width: 100%;
    min-height: 25em;
`

const Title = styled.h3`
    color: rgb(0, 0, 0);
    text-align: center;
    width: 100%;
    text-shadow: 5px 5px 2px rgba(0, 0, 0, 0.2);
`

const Subtitle = styled.h4`
    color: rgb(0, 0, 0);
    text-align: center;
    width: 100%;
    text-shadow: 5px 5px 2px rgba(0, 0, 0, 0.2);
    font-weight: normal;
    font-size: 0.87em;
`

const FormStyled = styled.form`
    display: flex;
    flex-direction: column;
    align-items: center;
    gap: 1em;
    margin-top: 2em;
`

const TextAreaStyled = styled.textarea`
    background-color: #e6e6e6;
    color: #000;
    width: 34em;
    height: 13em;
    padding: 0.5em;
    border: none;
    border-radius: 5px;
    resize: none;
`

const ButtonStyled = styled.button`
    padding: 0.7em 2em;
    border: none;
    border-radius: 0.3125em;
    background-color: #4287f5;
    color: white;
    cursor: pointer;
    transition: background-color 0.3s;

    &:hover {
        background-color: #326ac0;
    }
`

const Form = forwardRef((props, ref) => (
  <FormContainer ref={ref}>
    <Title>Formulário de Contato</Title>
    <Subtitle>
      Ficou com alguma dúvida? Preencha o formulário abaixo com seus dados e sua dúvida, que iremos retornar assim que possível!
    </Subtitle>
    <FormStyled>
      <Input type='text' placeholder='Seu nome' />
      <Input type='email' placeholder='Seu e-mail' />
      <Input type='número' placeholder='Seu número' />
      <TextAreaStyled placeholder='Digite sua mensagem...' />
      <div>
        <ButtonStyled type='submit'>Enviar</ButtonStyled>
        <ButtonStyled type='reset' style={{ marginLeft: '1em' }}>
          Limpar
        </ButtonStyled>
      </div>
    </FormStyled>
  </FormContainer>
))

export default Form

