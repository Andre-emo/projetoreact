import Logo from '../Logo'
import MenuItems from '../MenuItems'
import MenuIcons from '../MenuIcons'
import './style.css'

function Header({scrollToForm }){
  const scrollToTop=()=>{
    window.scrollTo({top: 0, behavior:'smooth'})
  }

  return (
    <header className="app-header">
      <div onClick={scrollToTop} style={{cursor:'pointer'}}>
        <Logo/>
      </div>
      <nav className='menu-nav'>
        <MenuItems/>
        <MenuIcons onIconClick={scrollToForm}/>
      </nav>
    </header>
  )
}

export default Header