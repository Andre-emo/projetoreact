import styled from "styled-components"

const Input = styled.input`
    border: 1px solid rgb(23, 114, 2);
    background: #FFFFFF;
    border-radius: 50px;
    width: 15em;
    height: 2em;
    color: rgb(0, 0, 0);
    font-size: 1em;
    text-align: center;

    &::placeholder{
        color:rgb(5, 4, 1);
        font-size: 0.87em;
        text-align: center;
    }
`

export default Input