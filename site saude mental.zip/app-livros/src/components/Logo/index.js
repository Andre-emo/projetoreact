import logo from '../../images/saude.png'
import './style.css'

function Logo(){
    return(
    <div className="app-logo">
        <img className='logo' src={logo} alt='Figura do logotipo do site.'></img>
        <p><strong>Psico+</strong></p>
    </div>
    )
}

export default Logo;