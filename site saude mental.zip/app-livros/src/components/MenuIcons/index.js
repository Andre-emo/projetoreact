import './style.css'
import edit from '../../images/edit.svg'

const menuIcons = [edit]

function MenuIcons({onIconClick}){
  return (
    <ul className='icons'>
      {menuIcons.map((icon) => (
        <li className='icon-li'>
          <img
            className='menu-icon'
            src={icon}
            alt='ícone'
            onClick={onIconClick}
            style={{ cursor:'pointer'}}
          />
        </li>
      ))}
    </ul>
  )
}

export default MenuIcons