import './style.css'

const menuOptions = [
  {name:'UAPS', href:'#uaps'},
  {name:'CAPS', href:'#caps'},
  {name:'Posto', href:'#posto'},
]

function MenuItems() {
  return (
    <ul className='menu'>
      {menuOptions.map((option) => (
        <li className='item-menu' key={option.name}>
          <a href={option.href}>{option.name}</a>
        </li>
      ))}
    </ul>
  );
}

export default MenuItems