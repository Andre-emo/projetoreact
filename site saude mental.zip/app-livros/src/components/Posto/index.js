import styled from 'styled-components'
import posto from "../../images/posto.jpg"

const Title = styled.h2`
  color: rgb(0, 0, 0);
  text-align: left; 
  width: 100%;
  text-shadow: 5px 2px 2px rgba(0, 0, 0, 0.2);
  margin-bottom: 1em;
  text-align: left; 
`

const Subtitle = styled.h3`
  color: rgb(0, 0, 0);
  text-align: left; 
  width: 100%;
  text-shadow: 5px 2px 2px rgba(0, 0, 0, 0.2);
  margin: 1.5em 0 0.5em;
  text-align: left; 
`

const Text = styled.p`
  text-align: left; 
  width: 100%;
  text-shadow: 5px 2px 2px rgba(0, 0, 0, 0.2);
  margin-bottom: 1em;
  line-height: 1.5;
  text-align: left; 
`
const TopicList = styled.ul`
  list-style-type: none;
  padding-left: 1.5em;
  margin: 1em 0;
  text-align: left;
`

const TopicItem = styled.li`
  position: relative;
  margin-bottom: 0.8em;
  line-height: 1.5em;
  text-align: left; 
  
  &::before {
    content: "•";
    color:rgb(14, 27, 167);
    font-weight: bold;
    position: absolute;
    left: -1em;
  }
`

const TopicTitle = styled.strong`
  color: #333;
`

const SectionContainer = styled.section`
  padding: 1em;
  text-align: left;
`

function Posto(){
    return(
        <SectionContainer id='posto'>
            <Title>Posto de saúde central</Title>
            <img src={posto} alt='imagem do posto' className='imagemPosto'
            style={{width: '800px', height: 'auto',borderRadius: '10px'}}></img>
            <Subtitle>Localização e Atendimento</Subtitle>
            <Text>O posto de saúde também oferece a opção de falar com um psicólogo ou psiquiatra.</Text>
            <Text>Para fazer isso, pode-se marcar uma consulta com o clínico geral e explicar sua situação,
                depois disso, ele irá fazer um encaminhamento para o profissional adequado.</Text>
            <Text>É importante ressaltar que, caso seja sua primeira vez indo no posto, deve-se ir com um documento com foto e um comprovante de residência,
                para que te indiquem o posto mais perto de você para futura necessidade.
            </Text>
            <TopicList>
                <TopicItem>
                    <TopicTitle>Endereço: </TopicTitle>R. Getúlio Vargas, 739 - Centro
                </TopicItem>
            </TopicList>
            <TopicList>
                <TopicItem>
                    <TopicTitle>Telefone: </TopicTitle>(44) 3649-0200
                </TopicItem>
            </TopicList>
        </SectionContainer>
    )
}

export default Posto