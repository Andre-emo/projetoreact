import styled from 'styled-components'
import uaps from '../../images/uaps.jpg'


const Title = styled.h2`
  color: rgb(0, 0, 0);
  text-align: left; 
  width: 100%;
  text-shadow: 5px 2px 2px rgba(0, 0, 0, 0.2);
  margin-bottom: 1rem;
  text-align: left; 
`

const Subtitle = styled.h3`
  color: rgb(0, 0, 0);
  text-align: left; 
  width: 100%;
  text-shadow: 5px 2px 2px rgba(0, 0, 0, 0.2);
  margin: 1.5rem 0 0.5rem;
  text-align: left; 
`

const Text = styled.p`
  text-align: left; 
  width: 100%;
  text-shadow: 5px 2px 2px rgba(0, 0, 0, 0.2);
  margin-bottom: 1rem;
  line-height: 1.5;
  text-align: left; 
`

const TopicList = styled.ul`
  list-style-type: none;
  padding-left: 1.5rem;
  margin: 1rem 0;
  text-align: left;
`

const TopicItem = styled.li`
  position: relative;
  margin-bottom: 0.8rem;
  line-height: 1.5;
  text-align: left; 
  
  &::before {
    content: "•";
    color:rgb(14, 27, 167);
    font-weight: bold;
    position: absolute;
    left: -1rem;
  }
`

const TopicTitle = styled.strong`
  color: #333;
`

const SectionContainer = styled.section`
  padding: 1em;
  text-align: left;
`


function Uaps(){
    return(
        <SectionContainer id="uaps">
            <Title>Unidade de Atendimento Psicosocial(UAPS)</Title>
            <img src={uaps} alt='imagem da uaps' className='imagemUaps'
            style={{width: '600px', height: 'auto',borderRadius: '10px'}}></img>
            <Subtitle>Localização e Atendimento</Subtitle>
            <Text>A Uaps se localiza dentro da própria da universidade, no seminário, primeiro andar. Voltada para 
              atender alunos com necessidade de atendimendo psicológico e solitação de auxílios PROBEM.</Text>
            <TopicList>
              <TopicItem>
                <TopicTitle>Pedagoga: </TopicTitle>Renata Gotardo
              </TopicItem>
            </TopicList>
            <TopicList>
              <TopicItem>
                <TopicTitle>Assistentes Socias: </TopicTitle>Bruna Poggere e Ivanice Neres
              </TopicItem>
            </TopicList>
            <TopicList>
              <TopicItem>
                <TopicTitle>Psicólogo: </TopicTitle>Eduardo Sguarezzi
              </TopicItem>
            </TopicList>
            <TopicList>
              <TopicItem>
                <TopicTitle>Terceirizada: </TopicTitle>Vitória Ribeiro
              </TopicItem>
            </TopicList>
            <Text>Para conversar com eles sobre situação basta ir no primeiro andar do seminário, 
              ou se preferir pode entrar em contato com eles por estes meios: </Text>
              <TopicList>
                <TopicItem>
                  <TopicTitle>Email: </TopicTitle>uapspalotina@ufpr.br 
                </TopicItem>
              </TopicList>
              <TopicList>
                <TopicItem>
                  <TopicTitle>WhatsApp: </TopicTitle>(41) 98862-6186 
                </TopicItem>
              </TopicList>
              <TopicList>
                <TopicItem>
                  <TopicTitle>Instagram: </TopicTitle>@uapspalotina
                </TopicItem>
              </TopicList>                              
                                                   
        </SectionContainer>
    )

}

export default Uaps